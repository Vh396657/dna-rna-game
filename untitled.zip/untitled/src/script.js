// Initialize game variables
const board = document.getElementById('board');
const message = document.getElementById('message');
const dnaCards = ['A', 'T', 'C', 'G', 'A', 'T', 'C', 'G']; // DNA base pairs
const rnaCards = ['T', 'A', 'G', 'C', 'T', 'A', 'G', 'C']; // Complementary RNA codons

// Combine DNA and RNA cards into one array for the game
const cards = [...dnaCards, ...rnaCards];
let flippedCards = [];
let matchedCards = [];

// Shuffle the cards
function shuffle(array) {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
}

// Create the board
function createBoard() {
  shuffle(cards);
  board.innerHTML = '';
  cards.forEach((card, index) => {
    const cardElement = document.createElement('div');
    cardElement.classList.add('card');
    cardElement.dataset.index = index;
    cardElement.dataset.value = card;
    cardElement.addEventListener('click', flipCard);
    board.appendChild(cardElement);
  });
}

// Flip the card when clicked
function flipCard(event) {
  const clickedCard = event.target;

  if (clickedCard.classList.contains('flipped') || flippedCards.length === 2) return;

  clickedCard.classList.add('flipped');
  clickedCard.textContent = clickedCard.dataset.value;

  flippedCards.push(clickedCard);

  if (flippedCards.length === 2) {
    checkMatch();
  }
}

// Check if the two flipped cards match
function checkMatch() {
  const [card1, card2] = flippedCards;

  // DNA to RNA matching logic (correct pairings)
  const isMatch =
    (card1.dataset.value === 'A' && card2.dataset.value === 'T') ||
    (card1.dataset.value === 'T' && card2.dataset.value === 'A') ||
    (card1.dataset.value === 'C' && card2.dataset.value === 'G') ||
    (card1.dataset.value === 'G' && card2.dataset.value === 'C');

  if (isMatch) {
    card1.classList.add('matched');
    card2.classList.add('matched');
    matchedCards.push(card1, card2);

    if (matchedCards.length === cards.length) {
      message.textContent = 'Congratulations! You matched all cards!';
    }
  } else {
    setTimeout(() => {
      card1.classList.remove('flipped');
      card2.classList.remove('flipped');
      card1.textContent = '';
      card2.textContent = '';
    }, 1000);
  }

  flippedCards = [];
}

// Initialize the game
createBoard();